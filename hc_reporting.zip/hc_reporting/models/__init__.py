# -*- coding: utf-8 -*-

from . import employee_res_partner
from . import sale_order
